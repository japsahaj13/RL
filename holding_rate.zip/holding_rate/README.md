# Holding Cost Rate Calculator

This module provides a function to compute a dynamic holding cost rate based on inventory levels and demand forecasts for retail store inventory.

## Overview

The `compute_holding_cost_rate` function calculates a holding cost rate by:

1. Preprocessing the raw inventory and demand data
2. Computing the Excess Inventory Rate (EIR) for each record
3. Estimating the maximum holding cost rate (L) from business parameters
4. Using a logistic function to map the average EIR to a rate between 0 and L

## Requirements

- Python 3.6+
- pandas
- numpy

## Usage

### As a Standalone Script

```bash
python h_rate.py
```

This will run the function with default business parameters and display the calculated holding cost rate, plus sanity check results showing how the rate varies with different EIR values.

### As a Module

```python
import h_rate

# Calculate holding cost rate
rate = h_rate.compute_holding_cost_rate(
    csv_path='retail_store_inventory.csv',
    unit_cost=50,              # Cost per unit
    storage_fee=2,             # Storage fee per unit per period
    annual_finance_rate=0.12,  # 12% annual finance rate
    periods_per_year=12,       # Monthly periods
    spoilage_pct=0.02,         # 2% spoilage per period
    x0=0.25                    # Business threshold midpoint at 25% excess inventory
)
print(f"Holding cost rate: {rate}")
```

## Function Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| csv_path | str | Path to the CSV file containing inventory data |
| unit_cost | float | Cost per unit of product |
| storage_fee | float | Storage fee per unit per period |
| annual_finance_rate | float | Annual finance rate (e.g., 0.12 for 12%) |
| periods_per_year | int | Number of periods in a year (e.g., 12 for monthly) |
| spoilage_pct | float | Spoilage percentage per period (as a decimal) |
| x0 | float | Midpoint of the logistic function (EIR value where rate = L/2) |
| anchor_width | float | Width around x0 for anchor points (default: 0.1) |
| r_low_frac | float | Fraction of L for the lower anchor point (default: 0.2) |
| r_high_frac | float | Fraction of L for the higher anchor point (default: 0.8) |

## Key Concepts

- **L (Maximum Holding Cost Rate)**: The upper bound of the rate, calculated as: `storage_fee + capital_cost + spoilage_cost`
- **x0 (Midpoint)**: The EIR value where rate = L/2, represents your business threshold for excess inventory
- **Anchor Points**: Used to set the steepness (k) of the logistic curve
  - `EIR_low = x0 - anchor_width`
  - `EIR_high = x0 + anchor_width`
  - Rate at `EIR_low` is `r_low_frac * L` 
  - Rate at `EIR_high` is `r_high_frac * L`

## Logistic Function Behavior

The function maps the average Excess Inventory Rate (EIR) to a cost rate using a logistic function:

```
rate = L / (1 + e^(-k * (avg_eir - x0)))
```

Where:
- At EIR = x0, the rate equals L/2
- At EIR << x0, the rate approaches 0
- At EIR >> x0, the rate approaches L

## CSV File Format

The function expects a CSV file with at least the following columns:
- `Inventory Level`: Current inventory levels 
- `Demand Forecast`: Forecasted demand

 